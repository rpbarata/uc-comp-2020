1)
-Executar a função convertoToOneChannel no matlab e obtem uma imagem apenas com um canal

2) 
-Compilar
make compress456 

-Executar 
compress456 -e <file>

-Obtém um ficheiro .mtv. Este ficheiro foi geradao com o BW e o MFT.

3)
Executar AdaptiveArithmeticCompress.java com <inputfile> <outputfile>

Obtém imagem comprimida