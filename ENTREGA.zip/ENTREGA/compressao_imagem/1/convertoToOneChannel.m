function convertoToOneChannel(originalName)
%Converte uma imagem do tipo bmp com 3 tr�s canais RGB iguais, apenas
%para um canal
    original = imread(originalName);
    one = rgb2gray(original);
    
    outName = strcat(originalName, '_oneChannel.bmp');
    imwrite(one, outName);
end

