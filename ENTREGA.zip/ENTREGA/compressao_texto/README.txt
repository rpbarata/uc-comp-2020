PPM:
   Executar PPMCompress.java com <inputfile> <outputfile>

Bzip2:
  Para a compressão do ficheiro com o bzip2, não foi usado qualquer tipo de código pesquisado, mas usada a função do linux bzip2

	bzip2 -z war_and_peace.txt
	
	